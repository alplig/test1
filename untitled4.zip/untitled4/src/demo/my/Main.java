package demo.my;


public class Main {

    public static void main(String[] args) {
        User user = new User();

        for (int i =0; i <user.Name.size(); i++){
           switch ()

            case user.Name.get(i) ;
        System.out.println(user.Name.get(i));
        }
    }
}