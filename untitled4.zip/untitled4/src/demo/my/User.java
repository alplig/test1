package demo.my;


import java.util.Arrays;
import java.util.List;


public class User {
    List<String> Name = Arrays.asList("Имя1","Имя2","Имя3");
            //Arrays.asList ("Имя1","Имя2","Имя3");
}
